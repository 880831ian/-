﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 身分證產生器
{
    public partial class Form1 : Form
    {
        int Randomnumber; //取亂數0000001~9999999
        int sex; //性別
        int number; //縣市代表號碼
        int numberchange; //縣市號碼轉換 十位
        int numberchange1; //縣市號碼轉換 個位
        int Verification; // 驗證碼
        int Verification1; // 驗證碼 取餘數
        int code; //最終驗證碼
        int alladd; //亂數轉換相加
        //------
        public Form1()
        {
            InitializeComponent();
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            //-----亂數
            Random num = new Random();
            Randomnumber = num.Next(1000001, 9999999);
            //-----性別
            switch (comboBox_fm.Text)
            {
                case "男生":
                    sex = 1;
                    break;
                case "女生":
                    sex = 2;
                    break;
            }
            //-----城市
            switch (comboBox_city.Text)
            {
                case "臺北市":
                    number = 10;
                    textBox_id.Text = "A";
                    break;
                case "臺中市":
                    number = 11;
                    textBox_id.Text = ("B" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "基隆市":
                    number = 12;
                    textBox_id.Text = ("C" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "臺南市":
                    number = 13;
                    textBox_id.Text = ("D" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "高雄市":
                    number = 14;
                    textBox_id.Text = ("E" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "新北市(臺北縣)":
                    number = 15;
                    textBox_id.Text = ("F" + sex + Randomnumber.ToString() + Calc());
                    break;
                case " 宜蘭縣":
                    number = 16;
                    textBox_id.Text = ("G" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "桃園縣":
                    number = 17;
                    textBox_id.Text = ("H" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "新竹縣":
                    number = 18;
                    textBox_id.Text = ("J" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "苗栗縣":
                    number = 19;
                    textBox_id.Text = ("K" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "臺中縣":
                    number = 20;
                    textBox_id.Text = ("L" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "南投縣":
                    number = 21;
                    textBox_id.Text = ("M" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "彰化縣":
                    number = 22;
                    textBox_id.Text = ("N" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "雲林縣":
                    number = 23;
                    textBox_id.Text = ("P" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "嘉義縣":
                    number = 24;
                    textBox_id.Text = ("Q" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "臺南縣":
                    number = 25;
                    textBox_id.Text = ("R" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "高雄縣":
                    number = 26;
                    textBox_id.Text = ("S" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "屏東縣":
                    number = 27;
                    textBox_id.Text = ("T" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "花蓮縣":
                    number = 28;
                    textBox_id.Text = ("U" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "臺東縣":
                    number = 29;
                    textBox_id.Text = ("V" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "澎湖縣":
                    number = 30;
                    textBox_id.Text = ("X" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "陽明山":
                    number = 31;
                    textBox_id.Text = ("Y" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "金門縣":
                    number = 32;
                    textBox_id.Text = ("W" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "連江縣":
                    number = 33;
                    textBox_id.Text = ("Z" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "嘉義市":
                    number = 34;
                    textBox_id.Text = ("I" + sex + Randomnumber.ToString() + Calc());
                    break;
                case "新竹市":
                    number = 35;
                    textBox_id.Text = ("O" + sex + Randomnumber.ToString() + Calc());
                    break;
            }
        } //產生
        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
        } //開啟程式
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        } //關閉程式
        public int Calc() //驗證碼計算
        {
            string str = Randomnumber.ToString(); //將亂數放入字串中
            numberchange = number / 10;
            numberchange1 = number % 10;
            alladd = (str[0] - 48) * 7 + (str[1] - 48) * 6 + (str[2] - 48) * 5 + (str[3] - 48) * 4 + (str[4] - 48) * 3 + (str[5] - 48) * 2 + (str[6] - 48) * 1;
            Verification = (numberchange * 1 + numberchange1 * 9 + sex * 8 + alladd) % 10;
            Verification1 = Verification % 10;
            code = 10 - Verification;
            return code;
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (comboBox_city.Text != "" && comboBox_fm.Text !="")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        } //確認輸入欄位是否正確
    }
}
